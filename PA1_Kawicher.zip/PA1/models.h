#ifndef MODELS_H
#define MODELS_H

#include <QString>

struct pic {
    QString name;
    QString path;
    QString description;
    int priority;
};

#endif // MODELS_H
