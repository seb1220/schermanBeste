﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PA2_5B_Control
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //Beispielcode und -zeichnung, kann entfernt werden
            code.Text = "TURN RIGHT 45\r\nDRAW 50\r\nTURN RIGHT 30\r\nDRAW 50\r\nTURN LEFT 30\r\nDRAW 50";
            painter.Rotate(45); 
            painter.Draw(50);
            painter.Rotate(30);
            painter.Draw(50);
            painter.Rotate(-30);
            painter.Draw(50);
        }

        private void draw_Click(object sender, RoutedEventArgs e)
        {
            List<Token> tokens = new List<Token>();


        }
    }
}
